#!/bin/bash
service tomcat7 start

